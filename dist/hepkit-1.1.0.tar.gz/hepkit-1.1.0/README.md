# HEPKit

Tools for performing High Energy Physics analysis with Python

To install, run:

```
python setup.py install
```
